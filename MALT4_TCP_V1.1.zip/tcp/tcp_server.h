/*
 * tcp_api.h
 *
 *  Created on: 28 Apr 2020
 *      Author: leszek.zarzycki
 */

#ifndef TCP_API_H_
#define TCP_API_H_

#define TCP_LISTEN_PORT	5000 // Telent port number 23

void tcpServerTask( void *pdata );

#endif /* TCP_API_H_ */
