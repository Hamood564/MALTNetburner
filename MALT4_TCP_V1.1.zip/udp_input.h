/**
 * udp_input.h
 * Header for UDP IO task.
 * @author gavin.murray
 * @version MALT5.5
 * @date 2014-12-02
 */

#ifndef UDP_INPUT_H_
#define UDP_INPUT_H_


void udpInputTask( void *pdata );


#endif /* UDP_INPUT_H_ */
